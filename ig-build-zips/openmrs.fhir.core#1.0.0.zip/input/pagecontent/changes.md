This is a list of major changes to this implementation guide

** 2022-06-12 Initial Version ** based on FHIR R4

* Initial Version
